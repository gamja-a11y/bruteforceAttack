"""Cross-check all acceptance gates before emitting the audit verdict."""
from fractions import Fraction as F
from repaired_analyze import *
def rows(name):
    with (D/name).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
s=read(D/'replay_summary.json')
h=read(D/'source_hash_audit.json')
wsl=read(ROOT/'phase3_wsl_independent_verification.json')
r=rows('repaired_holdout_results.csv')
diag=rows('repaired_interval_diagnostics.csv')
tests=rows('integrity_test_results.csv')
nf10=[v for v in r if v['method']=='B' and v['nf']=='10']
nf3=[v for v in r if v['method']=='B' and v['nf']=='3' and v['target_met']=='False']
checks={
'보호 파일 SHA-256 및 파일 목록': h['before']==h['after'] and h['unchanged'],
'실제 재검증 및 원본 기록별 일치':s['replayed']==len(diag)==312 and not s['failures'] and len(r)==144,
'세 방법의 개별 성공·미달 재현':s['successful']=={'A':30,'B':30,'C':30} and all(sum(v['target_met']=='False' for v in r if v['method']==k)==18 for k in 'ABC'),
'기존 WSL 집계와 일치':s['successful']==wsl['verified_target_success_by_method'] and s['replayed']==wsl['certificates_found']==wsl['independently_verified'] and not wsl['failures'],
'Gram 양수 폭 복원':s['recovered']==292 and all(F(v['gram_norm_width_upper'])>=F(v['gram_norm_width_lower'])>=0 and (F(v['gram_norm_width_lower'])>0)==(F(v['gram_upper'])>max(0,F(v['gram_lower']))) for v in diag),
'반례 및 정상 대조':len(tests)==31 and all(v['passed']=='True' for v in tests),
'NF=10 및 NF=3 미달 원인':len(nf10)==16 and all(v['target_met']=='False' and F(v['field_delta'])>F('1e-5') for v in nf10) and len(nf3)==2 and all(F(v['absolute_width'])<=F('1e-5') and F(v['relative_width'])>F('0.01') for v in nf3)}
verdict='PASS' if all(checks.values()) else 'FAIL'
intro=f"""# Phase 3 최종 무결성 재감사 — {verdict}

원본 자료 {len(h['before'])}개를 작업 시작 전과 종료 후 SHA-256으로 대조했다. Windows에서 기존 독립 검증기를 다시 호출한 후보는 {s['replayed']}개이며, 소요 시간은 {s['seconds']:.2f}초다. 세 방법 모두 48건 중 30건에서 두 목표를 충족했고 18건에서 미달했다. 원본 CSV와 사례별로 대조했으며 성공·미달 조건의 이동은 없었다. 원래 실험의 시간·메모리는 CSV에서 historical로 표시한다.

|판정 기준|결과|
|---|---|
"""
intro+='\n'.join(f"|{k}|{'PASS' if v else 'FAIL'}|" for k,v in checks.items())
body=r"""
## 발견과 수정

1. 원래 집계기는 search.json의 성공 문자열과 저장된 검증 플래그를 사용했다. 후보가 없는 가짜 성공이나 다른 조건에서 나온 증거가 집계에 들어갈 가능성이 있었다. 수정 분석기는 사전 명세 → 경로 → 실행 기록 → 후보 파일 → 독립 verify 호출 순으로 연결한다. 모델, 입력, 차수, 비트, 재현한 선택 순서와 종료 지점, 최선 후보, 인증서 목록의 완결성, 검증기 반환값, 저장된 폭과 플래그를 대조한다. 마지막으로 같은 물리 조건·모델에서 A/B/C의 모든 구간에 공통점이 있는지 검사한다. 정상 자료에서 허위 성공이 발견된 건수는 0이다.
2. 기존 binary64 제곱근 차에서 양수 폭이 사라진 292건을 복구했다. 진단 CSV의 Gram 제곱 하한·상한·폭, 장 나머지와 최종 폭은 정확한 유리수다. Gram **노름** 폭만 방향을 지정한 십진 양끝으로 저장한다. 원래 인증 구간도 유리수로 복원했으며 재발급하지 않았다.
3. 기존 재시작은 search.json의 존재로 결정됐다. 새 재사용 가드는 사전에 신뢰한 외부 영수증 해시, 물리 입력, 정책·규칙·명세·수학 코드 해시, 자원 예산, 파일 집합과 해시를 대조한 뒤 전 후보를 다시 검증한다. 과거에 영수증을 만들지 않은 실행은 자동 재사용을 거절한다. 이번 사후 감사는 과거 런타임에 측정된 메모리 제한의 독립 증명이 아니다.
4. 과거 작업자 오류 처리에서 빈 stderr에 마지막 줄을 요청하면 IndexError가 발생할 수 있었다. 새 래퍼는 종료 코드, stderr 유무, 시간 초과, 파싱 실패, 독립 검증 실패, 인증서 무결성 실패를 구분한다.
5. T1–T15를 세분한 31개 검사의 기대 코드와 실제 코드는 integrity_test_results.csv에 있다. 위조된 성공, 없는 후보, 다른 모델·입력, 잘못된 차수, 손상된 증거, 안쪽으로 옮긴 끝점, 다른 명세 영수증, 누락·중복·고아 후보를 검사했다. T13은 서로소인 모의 구간을 교집합 검사에 직접 넣었다. 전체 데이터셋 양성 대조는 별도의 312개 재검증이다. 테스트 작성 중 누락된 Path 가져오기를 고쳐 전체 테스트를 다시 실행했다.

## 수학 감사 A–J

|항목|근거 및 판정|
|---|---|
|A. 노름|정리와 구현에서 \(N^2=(\pi R^2)^{-1}\int_{disk}|(i\lambda z)^{-1}\int_A D(q)\,ds|^2dr\)이다. 단위 입사장, 동일 반송파 제거, 균일 연속 면적 평균이다. RS 장의 노름으로 나누거나 위상을 피팅하는 단계는 없다.|
|B. 잔차|\(t=\sqrt{1+q},a=1/(1+q)+i/(Kt^3),D=a e^{iK(t-1)}-b e^{iK\psi}\). Fresnel은 \(b=1,\psi=q/2\). Padé는 \(b=(1+q)^{-1}+i(48+12q-q^2)/(K(48+84q+35q^2)),\ \psi=4q(q+2)/(16+12q+q^2)\). 발급기의 expm1 차와 검증기의 노드별 직접 차가 대수적으로 일치한다.|
|C. 보간|타원에서 해석적이며 절댓값이 M 이하인 복소함수는 Chebyshev 계수 꼬리와 Lobatto aliasing으로 최대 오차 \(4M\rho^{-n}/(\rho-1)\) 이하. \(\rho=2\)에서 검증기는 \(\epsilon\ge4M/2^n\) 및 노드 간격을 재검사한다. 보간 정리는 기존 증명을 사용한다.|
|D. 타원|\(h=Q/2, q=h+5h\cos(s)/4+3ih\sin(s)/4\). 512개 닫힌 호에서 M의 포함을 재계산하고 기하 범위와 직사각형 안의 가지·극점 배제 여유를 검사한다. 내부 상한은 최대절댓값 원리를 사용한다.|
|E. 개구 모멘트|대칭으로 홀수차는 0. \(\int_A s_x^{2i}s_y^{2j}=4a_x^{2i+1}a_y^{2j+1}\Gamma((2i+1)/p)\Gamma((2j+1)/p)/(p^2\Gamma(1+(2i+2j+2)/p))\). 사분면에서 두 축을 p제곱 변수로 바꾼 단체의 Dirichlet 적분이다. 검증기가 차수별 모멘트를 다시 조합한다.|
|F. 원판 Gram|단위 원판 면적 평균인 짝수 모멘트는 \((1/2)_i(1/2)_j/(i+j+1)!\), 반경 R의 원판에는 \(R^{2i+2j}\)를 곱한다. 극좌표 각 Beta 적분과 반경 적분에서 얻는다. 실수부 제곱과 허수부 제곱의 교차항을 포함해 행 다항식 곱으로 재계산한다.|
|G. 장 나머지|커널의 균등 오차를 적분하면 \(\delta\ge100\pi\epsilon/(\lambda z)\). 같은 점별 상한이 면적 평균 RMS에도 적용된다. 검증기가 계수와 상향 반올림을 확인한다.|
|H. 양측 경계|Gram 구간을 [a,b]라 할 때 \(g_-=\sqrt{\max(0,a)},g_+=\sqrt b\). 삼각·역삼각부등식에 의해 끝점은 \(\max(0,g_--\delta),g_++\delta\)를 바깥으로 감싼다. 이상적인 폭은 \((g_+-g_-)+\delta+\min(g_-,\delta)\)이며 저장 폭에는 끝점 반올림 여유가 포함된다. Gram 폭은 \((b-\max(0,a))/(g_++g_-)\). 두 근이 모두 0이면 폭은 정확히 0이다. 정수 제곱근으로 각 근을 유리수 격자의 이웃 두 점에 가두고 양의 분모의 역순으로 나누므로 폭의 양끝이 엄밀하다.|
|I. 목표|정확한 이진 유리수 L,U를 사용한다. 절대폭은 U−L≤1/100000, 상대폭은 L>0이고 2(U−L)/(U+L)≤1/100인 경우만 통과한다.|
|J. 실패 원인|새 규칙 B에서 NF=10인 16건 전부 δ 자체가 1e−5를 초과했다. 폭은 하한 절단 후에도 δ 이상이므로 해당 인증 예산으로 절대 목표를 달성할 수 없다. NF=3의 Padé 미달 2건은 절대 목표를 충족하고 상대 목표에서 탈락했다. 이는 인증 폭에 관한 결과이며 실제 모델 오차의 크기가 δ라는 뜻은 아니다.|

## 이식성과 재현

Windows의 전체 재감사와 기존 Ubuntu/WSL 전체 재검증 JSON의 집계가 일치했다. 추가로 Ubuntu mp 환경에서 새 분석기를 사용해 01_Pade_C의 전체 검사를 실제 실행했다. 이번 Ubuntu 확인 범위는 해당 대표 런 하나다. 새 분석기는 Windows Job Object를 호출하지 않는다. Ubuntu에서 원 실험의 메모리 상한이 동일하게 시행되었다는 증거는 없다.

Python 3.10 이상, python-flint 0.9.0 및 FLINT 3.6.0, 원래 디렉터리 구조가 필요하다. Windows 실측은 Python 3.14.7이다. 새 감사 사본에서 다음 명령을 순서대로 실행한다. 기존 source_hash_audit.json이 있는 폴더에서는 before가 덮어쓰기를 거절한다. 원본 보호 범위는 세 연구 디렉터리 전체와 WSL 결과 JSON이다.

~~~powershell
cd fresnel_publication_phase3_audit_repaired
$env:PYTHONPATH="$env:USERPROFILE/AppData/Local/Temp/codex-fresnel-flint"
$py="$env:USERPROFILE/AppData/Local/Python/pythoncore-3.14-64/python.exe"
& $py -B source_hash.py before
& $py -B verify_all_certificates.py
& $py -B negative_integrity_tests.py
& $py -B source_hash.py after
& $py -B finish_report.py
~~~

Ubuntu에서는 같은 순서로 각 파일을 `python -B 파일명`으로 실행한다. 물리 입력은 명세의 양수 유한 십진 문자열을 사용한다. 정수, 소수, e/E와 부호 있는 십진 지수를 허용하며 공백, NaN, Infinity, 음수, 불리언은 허용하지 않는다. 인증 요청의 표기는 원 발급기의 Decimal 문자열과 일치해야 한다. 후보 정수 차수·정밀도는 명세의 이산 후보로 제한한다.

## 최종 판단과 Phase 4 전 남은 위험

이 24개 물리 조건에서 수학적 인증 증거와 결과 집계는 일치한다. 새로운 수치 검사는 기존 Theorem 1의 해석적 전제와 FLINT/Arb의 포함 연산에 의존한다. 별도 구현의 DCT와 Gram 재계산은 유용한 교차검사지만 다른 수치 라이브러리로 증명 전체를 재구성한 것은 아니다. 인증 대상은 스칼라 전파 모델이다. PEC 스크린의 Maxwell 해와의 일치는 이 감사의 판정 범위 밖이다.

Phase 4 전에 새 실행의 영수증과 명세 해시를 실행 이전부터 독립 보관하고, 두 플랫폼에서 같은 예산으로 반복 벤치마크할 필요가 있다. 과거 WSL JSON에는 사례별 서명이나 실행 이력이 없어 집계 비교에만 사용했다. 높은 NF의 목표 폭에 대해서는 더 높은 차수의 별도 사전 등록 실험이 필요하다. 이번 감사에는 인증서 신규 발급이나 기존 실험 재실행이 없다.
"""
(D/'final_phase3_audit_report.md').write_text(intro+'\n'+body,encoding='utf8')
print(verdict,checks)
if verdict!='PASS': raise SystemExit(1)

